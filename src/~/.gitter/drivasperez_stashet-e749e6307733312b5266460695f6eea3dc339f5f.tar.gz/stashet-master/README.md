![CI](https://github.com/drivasperez/stashet/workflows/CI/badge.svg)

# Stashet

WIP
